/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.beans;

/**
 *
 * @author mslceltp997
 */
public class RegistrationPage {
        private String username;
	private String dateOfBirth;
	private String Gender;
	private String panNo;
	private String bankAccountNo;
	private String bankName;
	private long mobileNo;
	private String address;
	private String bankPrivilegeCustomerNumber;
	private String password;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
		
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getBankAccountNo() {
		return bankAccountNo;
	}
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBankPrivilegeCustomerNumber() {
		return bankPrivilegeCustomerNumber;
	}
	public void setBankPrivilegeCustomerNumber(String bankPrivilegeCustomerNumber) {
		this.bankPrivilegeCustomerNumber = bankPrivilegeCustomerNumber;
	}

}
