/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.dao;

import com.techm.oar.beans.TicketBooking;
import com.techm.oar.utils.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author mslceltp997
 */
public class TicketBookingDaoImpl implements TicketBookingDao{

    public int bookTicket(TicketBooking booking) {
        int status=0;
        Connection con=null;
        PreparedStatement pst=null;
        String name = booking.getName();
        System.out.println(name);
        String gender = booking.getGender();
        String agency= booking.getAgency();
        String trip=booking.getTrip();
        String source=booking.getSource();
        String destination=booking.getDestination();
        int numberOfTickets=booking.getNumberOfTickets();
        long mobileNumber=booking.getMobileNumber();
        int registrationID=booking.getRegistrationID();
        System.out.println(registrationID);
        try{
            con=DBUtil.getConnection();
            System.out.println(con==null);
            pst=con.prepareStatement("insert into ticket_details1 values(?,?,?,?,?,?,?,?,?)");
            pst.setString(1,name);
            pst.setInt(2,registrationID);
            pst.setString(3,gender);
            pst.setString(4,agency);
            pst.setString(5,trip);
            pst.setString(6,source);
            pst.setString(7,destination);
            pst.setInt(8,numberOfTickets);
            pst.setLong(9,mobileNumber);
            status=pst.executeUpdate();
            
        }catch(SQLException se){
            se.printStackTrace();
        }
        DBUtil.closeConnection(con);
        return status;
    }

}
