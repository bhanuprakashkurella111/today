/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.serviceFactory;

import com.techm.oar.services.LoginService;
import com.techm.oar.services.LoginServiceImpl;
import com.techm.oar.services.RegistrationService;
import com.techm.oar.services.RegistrationServiceImpl;
import com.techm.oar.services.TicketBookingService;
import com.techm.oar.services.TicketBookingServiceImpl;
import com.techm.oar.services.TicketCancellationService;
import com.techm.oar.services.TicketCancellationServiceImpl;
import com.techm.oar.services.TicketDetailsService;
import com.techm.oar.services.TicketDetailsServiceImpl;

/**
 *
 * @author mslceltp997
 */
public class ServiceFactory {
       private ServiceFactory(){}
    public static LoginService getLoginService(){
        return new LoginServiceImpl();
    }
    public static RegistrationService getRegistrationService(){
        return new RegistrationServiceImpl();
    }
    public static TicketBookingService getTicketBookingService(){
        return new TicketBookingServiceImpl();
    }
    public static TicketCancellationService getTicketCancellationService(){
        return new TicketCancellationServiceImpl();
    }
    public static TicketDetailsService getTicketDetailsService(){
        return new TicketDetailsServiceImpl();
    }
}
