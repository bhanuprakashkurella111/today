/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.services;

import java.sql.ResultSet;

/**
 *
 * @author mslceltp997
 */
public interface TicketDetailsService {
        public ResultSet ticketDetails();
}
