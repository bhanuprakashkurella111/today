/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.services;

import com.techm.oar.beans.TicketBooking;
import com.techm.oar.dao.TicketBookingDao;
import com.techm.oar.daoFactory.DAOFactory;

/**
 *
 * @author mslceltp997
 */
public class TicketBookingServiceImpl implements TicketBookingService{

    public int bookTicket(TicketBooking booking) {
        TicketBookingDao ticketBookingDAO=DAOFactory.getTicketBookingDao();
        return ticketBookingDAO.bookTicket(booking);
    }
    
}
