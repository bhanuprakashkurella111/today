/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.services;

import com.techm.oar.beans.TicketCancellation;
import com.techm.oar.dao.TicketCancellationDao;
import com.techm.oar.daoFactory.DAOFactory;

/**
 *
 * @author mslceltp997
 */
public class TicketCancellationServiceImpl implements TicketCancellationService{

    public int cancelTicket(TicketCancellation cancel) {
        TicketCancellationDao ticketCancellationDAO=DAOFactory.getTicketCancellationDao();
        return ticketCancellationDAO.cancelTicket(cancel);
    }
    

}
