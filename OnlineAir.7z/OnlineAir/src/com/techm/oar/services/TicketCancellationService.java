/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.services;

import com.techm.oar.beans.TicketCancellation;

/**
 *
 * @author mslceltp997
 */
public interface TicketCancellationService {
        public abstract int cancelTicket(TicketCancellation cancel);
}
