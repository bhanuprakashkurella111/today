/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.controllers;

import com.techm.oar.beans.RegistrationPage;
import com.techm.oar.serviceFactory.ServiceFactory;
import com.techm.oar.services.RegistrationService;
import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class RegistrationServlet extends HttpServlet {
  
    
	private static final long serialVersionUID = 1L;

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

          RequestDispatcher rd=null;
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try{
            String userName=request.getParameter("username");
            String pwd=request.getParameter("password");
            String dob=request.getParameter("dateOfBirth");
            String gender=request.getParameter("gender");
            String panNum=request.getParameter("panNo");
            String bankAccNo=request.getParameter("bankAccountNo");
            String bName=request.getParameter("bankName");
            String addr=request.getParameter("address");
            String privilegeNo=request.getParameter("bankPrivilegeCustomerNumber");
            long mobNo=Long.parseLong(request.getParameter("mobileNo"));
            out.println(userName);
            RegistrationPage regInfo=new RegistrationPage();
            regInfo.setUsername(userName);
            regInfo.setPassword(pwd);
            regInfo.setDateOfBirth(dob);
            regInfo.setGender(gender);
            regInfo.setPanNo(panNum);
            regInfo.setBankAccountNo(bankAccNo);
            regInfo.setBankName(bName);
            regInfo.setAddress(addr);
            regInfo.setMobileNo(mobNo);
            regInfo.setBankPrivilegeCustomerNumber(privilegeNo);
            RegistrationService regSer=ServiceFactory.getRegistrationService();
            int value=regSer.registerUser(regInfo);
          
            if(value==1){
            request.getRequestDispatcher("registrationstatus.jsp").forward(request,response);
            
            }
            if(value==0){
           request.getRequestDispatcher("notSuccesfulRegistration.jsp");
          rd.forward(request,response);
        }
        } finally { 
            out.close();
        }
    } 

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    public String getServletInfo() {
        return "Short description";
    }
   
}
